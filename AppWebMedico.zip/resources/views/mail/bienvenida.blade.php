<h1> Bienvenido</h1>
<p>hola <strong>{{$nombre}}</strong>nos alegra la bienvenida a nuestra familia.</p>